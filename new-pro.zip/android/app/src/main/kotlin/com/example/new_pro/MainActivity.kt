package com.example.new_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
